//
//  ViewController.swift
//  PitchPerfect
//
//  Created by Ananya Saha on 3/1/22.
//

import UIKit

class RecodSoundViewController: UIViewController {

    @IBOutlet weak var recordingLabel: UILabel!
    @IBOutlet weak var recordButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("View did load")
        // Do any additional setup after loading the view.
        stopButton.isEnabled = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("View will appear")
    }
   

    @IBAction func recordButtonPressed(_ sender: Any) {
        print("Button pressed")
        recordingLabel.text = "Recording in progress"
        recordButton.isEnabled = false
        stopButton.isEnabled = true
    }
    
    @IBAction func stopButtonPressed(_ sender: Any) {
        print("Stop the recording!!!")
        recordButton.isEnabled = true
        stopButton.isEnabled = false
        recordingLabel.text = "Tap to Record"
        
    }
}

